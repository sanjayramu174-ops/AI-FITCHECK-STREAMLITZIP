
# AI FitCheck - Streamlit App

## Features
- Welcome page
- User details: age, gender, height, weight, activity, fitness goal
- BMI and BMI category
- BMR using Mifflin-St Jeor
- Estimated daily calorie requirement (TDEE)
- Goal calorie target for:
  - Weight Loss
  - Maintain Weight
  - Weight Gain
- Indian food calorie database
- Breakfast / Lunch / Snacks / Dinner tracking
- Quantity-based calorie calculation
- Timestamped meal log
- Daily calorie total and remaining calories
- Meal-wise calorie target comparison
- CSV export
- Exercise recommendation and estimated calorie burn

## Run

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Note
Food calories and exercise calorie burn are approximate. Recipe, portion, intensity and individual differences affect actual values.
