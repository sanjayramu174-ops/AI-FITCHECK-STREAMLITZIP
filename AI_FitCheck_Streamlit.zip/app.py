
import streamlit as st
import pandas as pd
from datetime import datetime, date

st.set_page_config(
    page_title="AI FitCheck",
    page_icon="🥗",
    layout="wide",
    initial_sidebar_state="expanded",
)

# -----------------------------
# Styling
# -----------------------------
st.markdown("""
<style>
    .main-title {
        font-size: 2.4rem;
        font-weight: 800;
        margin-bottom: 0.2rem;
    }
    .subtitle {
        font-size: 1.05rem;
        color: #666;
        margin-bottom: 1rem;
    }
    .metric-card {
        padding: 16px;
        border: 1px solid rgba(128,128,128,.25);
        border-radius: 16px;
        margin-bottom: 10px;
    }
    .small-note {
        color: #777;
        font-size: 0.88rem;
    }
</style>
""", unsafe_allow_html=True)

# -----------------------------
# Session state
# -----------------------------
defaults = {
    "screen": "Home",
    "profile": {},
    "metrics": {},
    "meal_log": [],
}
for k, v in defaults.items():
    if k not in st.session_state:
        st.session_state[k] = v

# -----------------------------
# Food database
# Calories are approximate
# -----------------------------
FOODS = {
    "Breakfast": {
        "Idli": {"unit": "piece", "cal": 58},
        "Sambar": {"unit": "100 ml", "cal": 60},
        "Coconut Chutney": {"unit": "1 tbsp", "cal": 45},
        "Dosa": {"unit": "piece", "cal": 168},
        "Chapati": {"unit": "piece", "cal": 120},
        "Pongal": {"unit": "100 g", "cal": 145},
        "Upma": {"unit": "100 g", "cal": 120},
        "Poha/Aval Upma": {"unit": "100 g", "cal": 130},
        "Boiled Egg": {"unit": "piece", "cal": 78},
        "Banana": {"unit": "small", "cal": 90},
        "Milk": {"unit": "100 ml", "cal": 62},
    },
    "Lunch": {
        "Cooked White Rice": {"unit": "100 g", "cal": 130},
        "Cooked Brown Rice": {"unit": "100 g", "cal": 123},
        "Sambar": {"unit": "100 ml", "cal": 60},
        "Rasam": {"unit": "100 ml", "cal": 35},
        "Curd": {"unit": "100 g", "cal": 61},
        "Vegetable Poriyal": {"unit": "100 g", "cal": 90},
        "Kootu": {"unit": "100 g", "cal": 110},
        "Chicken Curry": {"unit": "100 g", "cal": 190},
        "Fish Curry": {"unit": "100 g", "cal": 150},
        "Boiled Egg": {"unit": "piece", "cal": 78},
        "Chapati": {"unit": "piece", "cal": 120},
        "Dal": {"unit": "100 g", "cal": 120},
    },
    "Snacks": {
        "Tea with Milk & Sugar": {"unit": "100 ml", "cal": 55},
        "Coffee with Milk & Sugar": {"unit": "100 ml", "cal": 65},
        "Sundal": {"unit": "100 g", "cal": 160},
        "Peanuts": {"unit": "30 g", "cal": 170},
        "Apple": {"unit": "medium", "cal": 95},
        "Orange": {"unit": "medium", "cal": 62},
        "Banana": {"unit": "small", "cal": 90},
        "Buttermilk": {"unit": "200 ml", "cal": 70},
        "Murukku": {"unit": "piece", "cal": 75},
    },
    "Dinner": {
        "Chapati": {"unit": "piece", "cal": 120},
        "Idli": {"unit": "piece", "cal": 58},
        "Dosa": {"unit": "piece", "cal": 168},
        "Cooked White Rice": {"unit": "100 g", "cal": 130},
        "Vegetable Kurma": {"unit": "100 g", "cal": 135},
        "Chicken Curry": {"unit": "100 g", "cal": 190},
        "Fish Curry": {"unit": "100 g", "cal": 150},
        "Dal": {"unit": "100 g", "cal": 120},
        "Curd": {"unit": "100 g", "cal": 61},
        "Vegetable Soup": {"unit": "250 ml", "cal": 100},
    }
}

EXERCISES = {
    "Walking - moderate": 3.8,
    "Walking - brisk": 5.0,
    "Cycling - moderate": 6.8,
    "Badminton - recreational": 5.5,
    "Jogging": 7.0,
    "Yoga": 2.8,
    "Strength training - moderate": 3.5,
}

ACTIVITY_FACTORS = {
    "Sedentary (little/no exercise)": 1.20,
    "Lightly active (1-3 days/week)": 1.375,
    "Moderately active (3-5 days/week)": 1.55,
    "Very active (6-7 days/week)": 1.725,
    "Extra active (hard training/physical job)": 1.90,
}

def calculate_metrics(age, gender, height_cm, weight_kg, activity, goal):
    height_m = height_cm / 100
    bmi = weight_kg / (height_m ** 2)

    if bmi < 18.5:
        bmi_cat = "Underweight"
    elif bmi < 25:
        bmi_cat = "Normal"
    elif bmi < 30:
        bmi_cat = "Overweight"
    else:
        bmi_cat = "Obesity range"

    # Mifflin-St Jeor
    if gender == "Male":
        bmr = 10 * weight_kg + 6.25 * height_cm - 5 * age + 5
    elif gender == "Female":
        bmr = 10 * weight_kg + 6.25 * height_cm - 5 * age - 161
    else:
        male = 10 * weight_kg + 6.25 * height_cm - 5 * age + 5
        female = 10 * weight_kg + 6.25 * height_cm - 5 * age - 161
        bmr = (male + female) / 2

    tdee = bmr * ACTIVITY_FACTORS[activity]

    # Simple configurable goal adjustment
    if goal == "Weight Loss":
        goal_cal = max(1200, tdee - 400)
    elif goal == "Weight Gain":
        goal_cal = tdee + 300
    else:
        goal_cal = tdee

    return {
        "BMI": bmi,
        "BMI Category": bmi_cat,
        "BMR": bmr,
        "Daily Calorie Requirement": tdee,
        "Goal Calorie Target": goal_cal,
    }

def meal_targets(goal_cal):
    return {
        "Breakfast": goal_cal * 0.25,
        "Lunch": goal_cal * 0.35,
        "Snacks": goal_cal * 0.10,
        "Dinner": goal_cal * 0.30,
    }

def kcal_burned(met, weight_kg, minutes):
    return met * 3.5 * weight_kg / 200 * minutes

# -----------------------------
# Navigation
# -----------------------------
with st.sidebar:
    st.title("AI FitCheck")
    page = st.radio(
        "Navigation",
        ["Home", "User Details", "Health Summary", "Diet Tracker", "Exercise"],
        index=["Home", "User Details", "Health Summary", "Diet Tracker", "Exercise"].index(st.session_state.screen)
        if st.session_state.screen in ["Home", "User Details", "Health Summary", "Diet Tracker", "Exercise"] else 0
    )
    st.session_state.screen = page

    st.divider()
    if st.session_state.profile:
        st.caption("Current profile")
        st.write(f"**Age:** {st.session_state.profile.get('age')}")
        st.write(f"**Goal:** {st.session_state.profile.get('goal')}")
        st.write(f"**Weight:** {st.session_state.profile.get('weight')} kg")

# -----------------------------
# HOME
# -----------------------------
if page == "Home":
    st.markdown('<div class="main-title">AI FitCheck</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="subtitle">Your personal fitness assistant — small steps every day lead to a healthier life.</div>',
        unsafe_allow_html=True,
    )

    c1, c2, c3 = st.columns(3)
    with c1:
        st.info("📊 Calculate BMI, BMR and daily calorie needs.")
    with c2:
        st.success("🥗 Track Indian meals by food and quantity.")
    with c3:
        st.warning("🏃 Estimate exercise calories burned.")

    if st.button("GO →", use_container_width=True, type="primary"):
        st.session_state.screen = "User Details"
        st.rerun()

    st.markdown("""
    ### What this app does
    1. Collects basic user details.
    2. Calculates BMI, BMI category, BMR and estimated maintenance calories.
    3. Adjusts a calorie target for weight loss, maintenance or weight gain.
    4. Suggests meal-wise calorie allocation.
    5. Lets the user select common Indian foods and quantity.
    6. Stores breakfast/lunch/snacks/dinner entries with timestamps.
    7. Compares calories consumed with the daily target.
    8. Suggests exercises and estimates calories burned.
    """)

# -----------------------------
# USER DETAILS
# -----------------------------
elif page == "User Details":
    st.header("User Details")

    with st.form("profile_form"):
        c1, c2 = st.columns(2)
        with c1:
            age = st.number_input("Age", min_value=13, max_value=100, value=30, step=1)
            gender = st.selectbox("Gender", ["Male", "Female", "Other / Prefer not to say"])
            height = st.number_input("Height (cm)", min_value=100.0, max_value=230.0, value=170.0, step=0.5)
        with c2:
            weight = st.number_input("Weight (kg)", min_value=30.0, max_value=250.0, value=70.0, step=0.5)
            activity = st.selectbox("Activity Level", list(ACTIVITY_FACTORS.keys()), index=2)
            goal = st.selectbox("Fitness Goal", ["Weight Loss", "Maintain Weight", "Weight Gain"])

        submitted = st.form_submit_button("Submit", type="primary", use_container_width=True)

    if submitted:
        profile = {
            "age": int(age),
            "gender": gender,
            "height": float(height),
            "weight": float(weight),
            "activity": activity,
            "goal": goal,
        }
        metrics = calculate_metrics(age, gender, height, weight, activity, goal)
        st.session_state.profile = profile
        st.session_state.metrics = metrics
        st.session_state.screen = "Health Summary"
        st.rerun()

# -----------------------------
# HEALTH SUMMARY
# -----------------------------
elif page == "Health Summary":
    st.header("Health & Calorie Summary")

    if not st.session_state.metrics:
        st.warning("Please complete User Details first.")
        if st.button("Open User Details"):
            st.session_state.screen = "User Details"
            st.rerun()
    else:
        m = st.session_state.metrics
        c1, c2, c3, c4, c5 = st.columns(5)
        c1.metric("BMI", f"{m['BMI']:.1f}")
        c2.metric("BMI Category", m["BMI Category"])
        c3.metric("BMR", f"{m['BMR']:.0f} kcal")
        c4.metric("Daily Need", f"{m['Daily Calorie Requirement']:.0f} kcal")
        c5.metric("Goal Target", f"{m['Goal Calorie Target']:.0f} kcal")

        st.caption("BMR uses the Mifflin–St Jeor equation. Daily requirement is estimated from the selected activity level.")

        targets = meal_targets(m["Goal Calorie Target"])
        st.subheader("Suggested Calorie Split")
        df_targets = pd.DataFrame(
            [{"Meal": k, "Suggested Calories": round(v)} for k, v in targets.items()]
        )
        st.dataframe(df_targets, use_container_width=True, hide_index=True)

        if st.button("Continue to Diet Tracker →", type="primary"):
            st.session_state.screen = "Diet Tracker"
            st.rerun()

# -----------------------------
# DIET TRACKER
# -----------------------------
elif page == "Diet Tracker":
    st.header("Indian Food Diet Tracker")

    if not st.session_state.metrics:
        st.warning("Please complete User Details first.")
    else:
        goal_cal = st.session_state.metrics["Goal Calorie Target"]
        targets = meal_targets(goal_cal)

        meal = st.selectbox("Meal", ["Breakfast", "Lunch", "Snacks", "Dinner"])
        food = st.selectbox("Food Item", list(FOODS[meal].keys()))
        item = FOODS[meal][food]

        c1, c2, c3 = st.columns(3)
        with c1:
            st.text_input("Reference Unit", value=item["unit"], disabled=True)
        with c2:
            qty = st.number_input("Quantity / Number of Units", min_value=0.25, value=1.0, step=0.25)
        with c3:
            calculated = item["cal"] * qty
            st.metric("Estimated Calories", f"{calculated:.0f} kcal")

        entry_time = st.time_input("Time", value=datetime.now().time().replace(second=0, microsecond=0))

        if st.button("Add Food", type="primary", use_container_width=True):
            st.session_state.meal_log.append({
                "Date": date.today().isoformat(),
                "Time": entry_time.strftime("%H:%M"),
                "Meal": meal,
                "Food": food,
                "Quantity": qty,
                "Unit": item["unit"],
                "Calories": round(calculated, 1),
            })
            st.success(f"Added: {food} — {calculated:.0f} kcal")

        st.divider()
        st.subheader("Today's Intake")

        if st.session_state.meal_log:
            log_df = pd.DataFrame(st.session_state.meal_log)
            today_df = log_df[log_df["Date"] == date.today().isoformat()].copy()
            st.dataframe(today_df, use_container_width=True, hide_index=True)

            total = today_df["Calories"].sum()
            remaining = goal_cal - total

            c1, c2, c3 = st.columns(3)
            c1.metric("Calories Consumed", f"{total:.0f} kcal")
            c2.metric("Daily Target", f"{goal_cal:.0f} kcal")
            c3.metric("Remaining", f"{remaining:.0f} kcal")

            progress = min(max(total / goal_cal, 0.0), 1.0)
            st.progress(progress)

            st.subheader("Meal-wise Summary")
            meal_sum = today_df.groupby("Meal", as_index=False)["Calories"].sum()
            meal_sum["Target"] = meal_sum["Meal"].map(targets)
            meal_sum["Difference"] = meal_sum["Target"] - meal_sum["Calories"]
            st.dataframe(meal_sum, use_container_width=True, hide_index=True)

            csv = today_df.to_csv(index=False).encode("utf-8")
            st.download_button(
                "Download Today's Food Log (CSV)",
                csv,
                file_name=f"food_log_{date.today().isoformat()}.csv",
                mime="text/csv",
            )

            if st.button("Clear Today's Log"):
                st.session_state.meal_log = [
                    x for x in st.session_state.meal_log
                    if x["Date"] != date.today().isoformat()
                ]
                st.rerun()
        else:
            st.info("No food entries added yet.")

        st.caption(
            "Food calories are approximate averages. Recipe, oil, serving size and brand can change the actual calorie value."
        )

# -----------------------------
# EXERCISE
# -----------------------------
elif page == "Exercise":
    st.header("Exercise Recommendation & Calorie Burn")

    if not st.session_state.profile:
        st.warning("Please complete User Details first.")
    else:
        weight = st.session_state.profile["weight"]
        goal = st.session_state.profile["goal"]

        if goal == "Weight Loss":
            st.info("Suggested pattern: combine regular walking/cardio with 2–3 strength sessions per week, based on your ability.")
        elif goal == "Weight Gain":
            st.info("Suggested pattern: prioritise progressive strength training and adequate recovery; cardio can remain moderate.")
        else:
            st.info("Suggested pattern: combine cardio, strength and mobility work for general fitness.")

        exercise = st.selectbox("Exercise", list(EXERCISES.keys()))
        minutes = st.slider("Duration (minutes)", 5, 120, 30, 5)
        burn = kcal_burned(EXERCISES[exercise], weight, minutes)

        c1, c2, c3 = st.columns(3)
        c1.metric("Exercise", exercise)
        c2.metric("Duration", f"{minutes} min")
        c3.metric("Estimated Burn", f"{burn:.0f} kcal")

        st.caption(
            "Exercise calorie burn is an estimate based on MET values, body weight and duration. Actual burn varies by intensity and individual factors."
        )

        if st.session_state.meal_log:
            df = pd.DataFrame(st.session_state.meal_log)
            today = df[df["Date"] == date.today().isoformat()]
            intake = today["Calories"].sum() if not today.empty else 0
        else:
            intake = 0

        goal_cal = st.session_state.metrics.get("Goal Calorie Target", 0)
        st.subheader("Daily Snapshot")
        c1, c2, c3 = st.columns(3)
        c1.metric("Food Intake", f"{intake:.0f} kcal")
        c2.metric("Exercise Burn", f"{burn:.0f} kcal")
        c3.metric("Net After Exercise", f"{intake - burn:.0f} kcal")

        st.warning(
            "This app is an educational fitness tracker, not a medical diagnosis or personalised clinical diet prescription. "
            "People with medical conditions, pregnancy, eating disorders, or special nutrition needs should use professional guidance."
        )
